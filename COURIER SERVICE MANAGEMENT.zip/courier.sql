-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2023 at 02:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `courier`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `UName` varchar(255) NOT NULL,
  `Upassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UName`, `Upassword`) VALUES
('admin', 'admin123'),
('alan', 'alan1');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Name` varchar(256) NOT NULL,
  `Mobile Number` int(100) NOT NULL,
  `NIC` varchar(256) NOT NULL,
  `Email Id` varchar(256) NOT NULL,
  `Sender_Address` varchar(256) NOT NULL,
  `Receiver_Address` varchar(256) NOT NULL,
  `Items` int(100) NOT NULL,
  `Amount` int(100) NOT NULL,
  `Description` varchar(256) NOT NULL,
  `Delivery_Status` varchar(256) NOT NULL,
  `ID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Name`, `Mobile Number`, `NIC`, `Email Id`, `Sender_Address`, `Receiver_Address`, `Items`, `Amount`, `Description`, `Delivery_Status`, `ID`) VALUES
('ashhaab', 7500244, '963425', 'ashnah@gmail.com', 'katubedda', 'colombo', 1, 1000, 'parts', 'pending', 3),
('nahda', 716517235, '234591v', 'nahd@gmail.com', 'katubedda', 'moratuwa', 3, 2800, 'parcel', 'yes', 4),
('Naveen', 912234455, '99234v', 'zayans@gmail.com', 'kaluthara', 'dehiwala', 2, 1000, 'lock', 'yes', 6),
('Amal Perera', 774058087, '8523456789v', 'amals@gmail.com', 'kiribathgoda', 'malabe', 3, 500, 'sell', 'no', 7),
('Janith Dilshan', 2147483647, '2000456678900', 'knc@gmail.com', 'wellawatte', 'katubedda', 2, 500, 'weligama', 'yes', 8),
('nishad ahamed', 716517235, '985678900v', 'nk@gmail.com', 'Galle', 'kelaniya', 2, 1000, 'cloths', 'pending', 9),
('navee', 712345, '902131234v', 'nah@gmail.com', 'colombo', 'gampaha', 1, 200, 'book', 'yes', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

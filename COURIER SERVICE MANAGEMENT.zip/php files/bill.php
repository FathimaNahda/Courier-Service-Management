<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bill.css">
    <title>Bill</title>
</head>
<body>
<div class="wrapper">
    <div class="form-box">
        <?php
        include_once 'data.php';
        $obj = new ManageData();

        if(isset($_GET['id'])) {
            $id = $_GET['id'];
            $billData = $obj->fetchDataById($id)->fetch_assoc();
            $hashedId = hash('sha256', $id); // hash method for ID
        } else {
            // Handle the case where the ID is not provided or invalid
            echo "Invalid or missing ID.";
            exit;
        }
        ?>

        <table>
            <tr>
                <th colspan="2">Bill Details</th>
            </tr>
            <tr>
                <td colspan="2">Reference No: <?php echo $billData['ID']; ?></td>
            </tr>
            <tr>
                <td colspan="1">
                    Customer Name: <?php echo $billData['Name']; ?><br>
                    Mobile Number: <?php echo $billData['Mobile Number']; ?><br>
                    NIC: <?php echo $billData['NIC']; ?><br>
                    Email Id: <?php echo $billData['Email Id']; ?><br>
                    Sender's Address: <?php echo $billData['Sender_Address']; ?>
                </td>
                <td>
                    Receiver's Address: <?php echo $billData['Receiver_Address']; ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">No of Items: <?php echo $billData['Items']; ?></td>
            </tr>
            <tr>
                <td colspan="2">Amount: <?php echo $billData['Amount']; ?></td>
            </tr>
            <tr>
                <td colspan="2">Description: <?php echo $billData['Description']; ?></td>
            </tr>
            <tr>
                <td colspan="2">Delivery Status: <?php echo $billData['Delivery_Status']; ?></td>
            </tr>
            <tr>
            <td colspan="2" class="button-container" style="padding-left:60%">
            <button  class="btn-cancel" name="action"><a href="dashboard.php">Cancel</a></button>
            <button class="btn-print" name="action" onclick="window.print('.$id.')">Print</button>
                
                </td>
            </tr>

        </table>
    </div>
</div>
</body>
</html>

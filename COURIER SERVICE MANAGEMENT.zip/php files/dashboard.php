<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Courier Pvt Ltd</title>
    <link rel="stylesheet" href="ds.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>  
    <div class="wrapper">
    <span class="bg-animate"></span>
    <div class="form-box">
        <h2> Customer Details </h2>
        <div class="both">
        <div class="container">
                    <div class="row height d-flex justify-content-center align-items-center">
                      <div class="col-md-8">
                      <form method="GET" action="dashboard.php">
        <div class="search">
            <i class="fa fa-search"></i>
            <input type="text" name="search_query" class="form-control" placeholder="Search here..">
            <button type="submit" class="btn" name="action" value="search">Search</button>
            <button type="submit" class="btn" name="action" value="refresh" >Refresh</button>
            
        </div>
    </form>
    
                      </div>
                    </div>
                </div>


        <div class="side">
        <button class="btn"><a href="register.php"> Add Customer</a></button>

        <button class="btn-print" name="action" onclick="window.print('.$id.')" style="margin-left:120px; 
        height:30px;width:106px;height:40px;">Print</button>
            
</div>
</div>

    </div>
   
   
    <div id="search-results" class="table-container">
        <table class="table">
  <thead>
    <tr>
      <th scope="col">Ref</th>
      <th scope="col">Name</th>
      <th scope="col">Mobile Number</th>
      <th scope="col">NIC</th>
      <th scope="col">Email Id</th>
      <th scope="col">Sender_Address</th>
      <th scope="col">Receiver_Address</th>
      <th scope="col">Items</th>
      <th scope="col">Amount</th>
      <th scope="col">Description</th>
      <th scope="col">Delivery_Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>


  <?php
include_once 'data.php';
$obj = new ManageData();
$result = $obj->fetchAllData();

if (isset($_GET['action']) && $_GET['action'] === 'search') {// search record
  $searchQuery = $_GET['search_query'];
  $filteredResults = array();
  
  while ($row = $result->fetch_assoc()) {
      if (strpos($row['ID'], $searchQuery) !== false) {
          $filteredResults[] = $row;
      }
  }
} else {
  $filteredResults = $result->fetch_all(MYSQLI_ASSOC);
}
$searchResultsHtml = '';
foreach ($filteredResults as $row) {
     // Corrected typo here
        $id = $row['ID'];
        $name = $row['Name'];
        $mb = $row['Mobile Number'];
        $nc = $row['NIC'];
        $em = $row['Email Id'];
        $saddress = $row['Sender_Address'];
        $raddress = $row['Receiver_Address'];
        $itm = $row['Items'];
        $amt = $row['Amount'];
        $desc = $row['Description'];
        $ds = $row['Delivery_Status'];
        echo '<tr>
        <th scope="row">' . $id . '</th>
            <td>' . $name . '</td>
            <td>' . $mb . '</td>
            <td>' . $nc . '</td>
            <td>' . $em . '</td>
            <td>' . $saddress . '</td>
            <td>' . $raddress . '</td>
            <td>' . $itm . '</td>
            <td>' . $amt . '</td>
            <td>' . $desc . '</td>
            <td>' . $ds . '</td>
            <td>
            <button class="btn-update"><a href="update.php?id=' . $id . '">Update</a></button>
            <button class="btn-delete" name="$action" onclick="confirmDelete('.$id.')">Delete</button>
            <button class="btn-print" name="$action"><a  href="bill.php?id=' . $id . '" target="_blank">Bill</a></button>
            

            </td> 
            </tr>';
           
    }
    echo $searchResultsHtml;

?>
 
  </tbody>

</table>
    </div>  

</div>

<script>
  function updateSearchResults() {
    const searchQuery = document.querySelector('[name="search_query"]').value;
    const xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                document.getElementById("search-results").innerHTML = xhr.responseText;
            } else {
                console.error("Error fetching search results");
            }
        }
    };

    xhr.open("GET", `dashboard.php?action=search&search_query=${searchQuery}`, true);
    xhr.send();
}
function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this record?")) {
        window.location.href = "data.php?action=delete&id=" + id;
    }
}
</script>
</body>
</html>
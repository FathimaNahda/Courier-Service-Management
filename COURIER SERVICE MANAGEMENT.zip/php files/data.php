<?php

abstract class DatabaseConnection {
    private $host = "localhost";
    private $user = "root";
    private $password = "";
    private $db = "courier";

    protected $conn;

    function __construct() {
        $this->conn = new mysqli($this->host, $this->user, $this->password, $this->db);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    abstract public function store($action); //register
    abstract public function fetchAllData(); // to display data in the dashboard table
    abstract public function fetchDataById($id); // to connect with update page of selected record
    abstract  public function deleteData($idToDelete); // delete each row 
    abstract public function updateData($idUpdate, $name, $nc, $em, $saddress, $raddress, $itm, 
    $amt, $desc, $ds); // in update page change the reocrd
    abstract public function checkMobileNumber($mobileNumber); // for customer login 
    
}

class ManageData extends DatabaseConnection {
    public function store($action) {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"])) {
            // Generate a new ID 
            $sql_get_max_id = "SELECT MAX(ID) AS max_id FROM `register`";
            $result = $this->conn->query($sql_get_max_id);
            $row = $result->fetch_assoc();
            $id = $row["max_id"] + 1;
            $name = $this->conn->real_escape_string($_POST['name']);
            $mb = $this->conn->real_escape_string($_POST['mobileno']);
            $nc = $this->conn->real_escape_string($_POST['nic']);
            $em = $this->conn->real_escape_string($_POST['email']);
            $saddress = $this->conn->real_escape_string($_POST['senderaddress']);
            $raddress = $this->conn->real_escape_string($_POST['receiveraddress']);
            $itm = $this->conn->real_escape_string($_POST['items']);
            $amt = $this->conn->real_escape_string($_POST['amount']);
            $desc = $this->conn->real_escape_string($_POST['description']);
            $ds = $this->conn->real_escape_string($_POST['deliverystatus']);
            if ($action == "register") {
                $sql = "INSERT INTO `register`(`ID`,`Name`, `Mobile Number`, `NIC`, `Email Id`, `Sender_Address`,
                `Receiver_Address`, `Items`, `Amount`, `Description`, `Delivery_Status`) VALUES 
                ('$id','$name','$mb','$nc','$em','$saddress','$raddress','$itm','$amt','$desc','$ds')";
               
                 $rs = $this->conn->query($sql);
                 if ($rs) {
                    echo "<script>";
                    echo "alert('Customer Registered Successfully');";
                    echo "window.location.href = 'dashboard.php';";
                    echo "</script>";
                } else {
                    echo "Error: " . $this->conn->error;
                }   
            }   
        }
        
    }
    public function fetchAllData() {
        $sql = "SELECT `ID`, `Name`, `Mobile Number`, `NIC`, `Email Id`, `Sender_Address`, `Receiver_Address`, 
        `Items`, `Amount`, `Description`, `Delivery_Status` FROM `register` ORDER BY `ID` DESC";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function fetchDataById($id){
        $id = $this->conn->real_escape_string($id);
        $sql = "SELECT `ID`, `Name`, `Mobile Number`, `NIC`, `Email Id`, `Sender_Address`, `Receiver_Address`, 
        `Items`, `Amount`, `Description`, `Delivery_Status` FROM `register` WHERE `ID`='$id'";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function deleteData($idToDelete) {
        $idToDelete = $this->conn->real_escape_string($idToDelete);
        $sql = "DELETE FROM `register` WHERE `ID`='$idToDelete'";
        $rs = $this->conn->query($sql);
        
        if (!$rs) {
            echo "Error deleting record: " . $this->conn->error;
        }
    }
    public function updateData($idUpdate, $name, $nc, $em, $saddress, $raddress, $itm, $amt, $desc, $ds) {
        $idUpdate =  $this->conn->real_escape_string($idUpdate);
        $name = $this->conn->real_escape_string($name);
        $nc = $this->conn->real_escape_string($nc);
        $em = $this->conn->real_escape_string($em);
        $saddress = $this->conn->real_escape_string($saddress);
        $raddress = $this->conn->real_escape_string($raddress);
        $itm = $this->conn->real_escape_string($itm);
        $amt = $this->conn->real_escape_string($amt);
        $desc = $this->conn->real_escape_string($desc);
        $ds = $this->conn->real_escape_string($ds);

        $sql = "UPDATE `register` SET `Name`='$name', `NIC`='$nc', `Email Id`='$em',
        `Sender_Address`='$saddress', `Receiver_Address`='$raddress', `Items`='$itm', `Amount`='$amt', 
        `Description`='$desc', `Delivery_Status`='$ds' WHERE `ID`='$idUpdate'";

        $result = $this->conn->query($sql);
        
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function checkMobileNumber($mobileNumber) {
        $mobileNumber = $this->conn->real_escape_string($mobileNumber);
        $sql = "SELECT COUNT(*) AS count FROM `register` WHERE `Mobile Number`='$mobileNumber'";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['count'] > 0;
    }
    
}

$action = $_POST["action"] ?? ""; // Get the action from the form to register

if (!empty($action)) {
    $obj = new ManageData();
    $obj->store($action);
    
}

// DELETE ROW 
$action = $_GET["action"] ?? ""; 

if (!empty($action)) {
    $obj = new ManageData();
    
    if ($action == "delete" && isset($_GET['id'])) {
        $idToDelete = $_GET['id'];
        $obj->deleteData($idToDelete);
        header("Location: dashboard.php");
    }
    
    $obj->store($action);
}

// UPDATE DATA  
$action = $_POST["action"] ?? "";
if ($action === "update" && isset($_POST['id'])) {
    $obj = new ManageData();
    // Gather form data
    $idUpdate = $_POST['id'];
    $name = $_POST['name'];
    $nc = $_POST['nic'];
    $em = $_POST['email'];
    $saddress = $_POST['senderaddress'];
    $raddress = $_POST['receiveraddress'];
    $itm = $_POST['items'];
    $amt = $_POST['amount'];
    $desc = $_POST['description'];
    $ds = $_POST['deliverystatus'];

    // Call the update method and handle the result
    $result = $obj->updateData($idUpdate, $name, $nc, $em, $saddress, $raddress, $itm, $amt, $desc, $ds);
    if ($result) {
        echo "<script>";
        echo "window.location.href = 'dashboard.php';";
        echo "alert('Record Updated Successfully!');";
        echo "</script>";
    } else {
        echo "<script>";
        echo "alert('Error updating record: " . $obj->conn->error . "');";
        echo "window.location.href = 'dashboard.php';";
        echo "</script>";
    }
}

//view customer delivery status info
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["custommerinfo"])) {
    $mobileNumber = $_POST["mobile"];
    $obj = new ManageData();

    if ($obj->checkMobileNumber($mobileNumber)) {
        // Fetch data based on the mobile number
        $result = $obj->fetchAllData(); // Fetch all data
        while ($row = $result->fetch_assoc()) {
            if ($row['Mobile Number'] == $mobileNumber) {
                $fetchedData = $row;
                break;
            }
        }

        if (isset($fetchedData)) {
            $hashedId =  hash('sha256', $fetchedData['ID']);
            // Redirect to status.php and pass data using URL parameters
            header("Location: status.php?hid={$hashedId}&name={$fetchedData['Name']}&mobileno={$fetchedData['Mobile Number']}&deliverystatus={$fetchedData['Delivery_Status']}");
            exit();
        } else {
            echo "<script>";
            echo "alert('Error: Mobile number not found in the record.');";
            echo "window.location.href = 'customer.php';";
            echo "</script>";
        }
    } else {
        echo "<script>";
        echo "alert('Error: Mobile number not found in the record.');";
        echo "window.location.href = 'customer.php';";
        echo "</script>";
    }
}


?>
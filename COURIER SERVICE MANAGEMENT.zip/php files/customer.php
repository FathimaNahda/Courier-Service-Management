<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Courier Pvt Ltd</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <span class="bg-animate"></span>
        <div class="form-box">
            <h2>Delivery Status</h2>
            <form action="data.php" method="post">
                <div class="input-box">
                    <input type="number" name=mobile required>
                    <label>Mobile Number</label>
                    <i class="bx bxs-user"></i>
                </div>
               
                <button type="submit"class="btn" name="custommerinfo">Get Info</button>
                
            </form>
        </div>  
        <div class="info-text">
            <h2>Fast Courier Pvt Ltd !</h2>
        </div>
    </div>

    
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Courier Pvt Ltd</title>
    <link rel="stylesheet" href="style.css">
</head>
<body> <div class="wrapper">
    <span class="bg-animate"></span>
    <div class="form-box">
        <h2>Registration</h2>
        <form action="data.php" method="post">
        <div class="input-box">
                <label>ID</label>  
            </div>
            <div class="input-box">
                <input type="text" name="name" required>
                <label>Name</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="mobileno" required  >
                <label>Mobile Number</label>
                <i class="bx bxs-lock-alt"></i>
            </div>

            <div class="input-box">
                <input type="text" name="nic" required >
                <label>NIC</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="email" name="email"required >
                <label>Email Id</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="senderaddress" required >
                <label>Sender's Address </label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="receiveraddress" required>
                <label>Receiver's Address </label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="items" required >
                <label>Items</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="amount" required>
                <label>Amount</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="description" required>
                <label>Description</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="deliverystatus" required>
                <label>Delivery Status</label>
                <i class="bx bxs-user"></i>
            </div>
            <button type="submit" class="btn" name="action" value="register" >Register</button> 
            <button type="button" class="btn" onclick="clearFields()">Clear</button>
         
        </form>    
    </div>
<!--  view button connects to admin dashboard -->
 <button type="submit" class="btn" style="width:110px; margin-top:912px; margin-left:305px">
 <a href="dashboard.php">View</a></button>
    <script>
        function clearFields() {
            // Loop through all input elements and set their values to empty
            const inputFields = document.querySelectorAll('input');
            inputFields.forEach(input => {
                input.value = '';
            });
        }
    </script>
   
   
</body>
</html>
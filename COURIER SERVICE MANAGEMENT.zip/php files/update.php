<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Courier Pvt Ltd</title>
    <link rel="stylesheet" href="style.css">
</head>
<body> <div class="wrapper">
    <span class="bg-animate"></span>
    <div class="form-box">
        <h2>Update</h2>
        <form action="data.php" method="post">
        <?php
            include_once 'data.php';
            $obj = new ManageData();

            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $result = $obj->fetchDataById($id);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $name = $row['Name'];
                        $mb = $row['Mobile Number'];
                        $nc = $row['NIC'];
                        $em = $row['Email Id'];
                        $saddress = $row['Sender_Address'];
                        $raddress = $row['Receiver_Address'];
                        $itm = $row['Items'];
                        $amt = $row['Amount'];
                        $desc = $row['Description'];
                        $ds = $row['Delivery_Status'];
                    }
                else {
                        // No data found for the provided ID
                        header("location: dashboard.php");
                        exit;
                    }
            }
            
            else{
                header("location: dashboard.php");
                exit;
            }  
            ?>
            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                <label>ID</label>
                <i class="bx bxs-user"></i>

            <div class="input-box">
                <input type="text" name="name" required value="<?php echo isset($name)?$name:'';?>">
                <label>Name</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="mobileno" required value="<?php echo isset($mb)?$mb : ''; ?>">
                <label>Mobile Number</label>
                <i class="bx bxs-lock-alt"></i>
            </div>

            <div class="input-box">
                <input type="text" name="nic" required value="<?php echo isset($nc)?$nc:'';?>"  >
                <label>NIC</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="email" name="email" required value="<?php echo isset($em)?$em:'';?>">
                <label>Email Id</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text"  name="senderaddress" required value="<?php echo isset($saddress)?$saddress:'';?>">
                <label>Sender's Address </label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="receiveraddress" required value="<?php echo isset($raddress)?$raddress:'';?>">
                <label>Receiver's Address </label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="items" required value="<?php echo isset($itm)?$itm:'';?>">
                <label>Items</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="number" name="amount" required value="<?php echo isset($amt)?$amt: ''; ?>">
                <label>Amount</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text"name="description" required value="<?php echo isset($desc)?$desc:'';?>">
                <label>Description</label>
                <i class="bx bxs-user"></i>
            </div>
            <div class="input-box">
                <input type="text" name="deliverystatus" required value="<?php echo isset($ds)?$ds:'';?>">
                <label>Delivery Status</label>
                <i class="bx bxs-user"></i>
            </div>
            <button type="submit" class="btn" name="action" value="update">Save</button>
            <button type="submit" class="btn"><a href="dashboard.php">Cancel</a></button>  
        </form> 
</body>
</html>
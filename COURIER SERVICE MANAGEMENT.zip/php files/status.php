<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Customer Status</title>
</head>
<body>
<div class="wrapper">

    <div class="form-box">
        <h2> Delivery Status</h2>
        <form action="data.php" method="post">

        <div class="input-box">
        <input type="text" name="hid" value="<?php echo isset($_GET['hid']) ? $_GET['hid'] : ''; ?>"
         style="width:610px">
        <label>Reference</label>
        <i class="bx bxs-user"></i>
        </div>

<div class="input-box">
    <input type="text" name="name" required value="<?php echo isset($_GET['name']) ? $_GET['name'] : ''; ?>">
    <label>Name</label>
    <i class="bx bxs-user"></i>
</div>

<div class="input-box">
    <input type="text" name="deliverystatus" required value="<?php echo isset($_GET['deliverystatus']) ? $_GET['deliverystatus'] : ''; ?>">
    <label>Delivery Status</label>
    <i class="bx bxs-user"></i>
</div>
    <button type="submit" class="btn" ><a href="customer.php">Exit</a></button>
        </form>
</div>
</div>
</body>
</html>
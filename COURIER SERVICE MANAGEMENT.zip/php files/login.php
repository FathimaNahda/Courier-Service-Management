<?php

 class MConnection {
    private $host = "localhost";
    private $user = "root";
    private $password = "";
    private $db = "courier";

    private $conn;
    private $username;
    private $psword; 
    private $mobileno; 

    //create constructor
    function __construct() {
        $this->conn = new mysqli($this->host, $this->user, $this->password, $this->db);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    function setUsername($username) {
        $this->username = $this->conn->real_escape_string($username);
    }
    
    function setPsword($psword) { 
        $this->psword = $this->conn->real_escape_string($psword);
    }

    function checkLogin() {
        $query = "SELECT * FROM login WHERE UName='$this->username' AND Upassword='$this->psword'";
        $result = $this->conn->query($query);

        if ($result->num_rows > 0) {
            // Correct username and password
            header("Location: register.php");
            exit(0);
        } 
        else {
            // Incorrect username or password
            echo "<script>alert('Incorrect username or password. Please try again.'); window.history.back();</script>";
        }
    }
 }

//get form input  data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
  
    $mconnection = new MConnection();
    hash("sha256", $mconnection->setUsername($username)) ;     
    hash("sha256", $mconnection->setPsword($password)) ;     
    $mconnection->checkLogin();
}

?>